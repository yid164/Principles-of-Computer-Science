#include <cstdlib>
#include <iostream>

#include "Stack.h"

using namespace std;

int main()
{
    //TODO: Testing goes here.
    //After implementing each function in Stack.cc (starting from given pseudocode),
    //write a few lines of code to test the new function in this file

    cout << "Goodbye" << endl;

    return EXIT_SUCCESS;
}
