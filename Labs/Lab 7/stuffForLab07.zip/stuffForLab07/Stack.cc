
#include <cstdlib>
#include <iostream>
#include "Stack.h"

Stack *CreateStack(const int cap){
    //TODO
    return NULL; 
}

void DestroyStack(Stack *stack){
    //TODO
}

bool ReadFromStack(Stack *stack, Element *el){
   //TODO
    return false;
}

void PrintStack(const Stack *stack){
    //TODO
}


