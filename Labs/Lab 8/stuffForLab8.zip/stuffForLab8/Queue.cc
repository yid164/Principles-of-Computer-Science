// file: Queue.cc
// CMPT 115

#include "Element.h"
#include "Queue.h"
#include <iostream>


// Algorithm createQueue(cap)
// Pre: cap :: integer, the capacity of the new Queue
// Post: allocates space for the Queue, total of cap Elements
// Return: a reference to the new Queue
Queue *createQueue(int capacity) {
  return NULL; 
}

// Algorithm destroyQueue()
// Post: deallocates space used by the Queue
void destroyQueue(Queue *q) {
}

// Algorithm enqueue(q,e)
// Pre: q :: reference to a Queue
//      e :: Element
// Post: Stores e in q
// Return: true if successful, false if queue is already full

bool enqueue(Queue *q, Element e) {
  return false;
}

// Algorithm dequeue(q,e)
// Pre: q :: reference to Queue
//      e :: reference to Element
// Post: copies data to *e, and removes it from queue
// Return: true if successful, false if queue is already empty

bool dequeue(Queue *q, Element *e) {
  return false;
}

// Algorithm queueSize(q)
// Pre: q :: reference to a Queue
// Return: the number of elements in the queue
int queueSize(Queue *q) {
  return 0;
}

// Algorithm queueEmpty(q)
// Pre: q :: reference to a Queue
// Return: true if the queue is empty, false otherwise
bool queueEmpty(Queue *q) {
  return false;
}


// Algorithm queueFull(q)
// Pre: q :: reference to a Queue
// Return: true if the queue is full, false otherwise
bool queueFull(Queue *q) {
  return false;
}


// end of file

