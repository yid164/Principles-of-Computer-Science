// file: Element.h
// CMPT 115

#ifndef _ELEMENT_H_
#define _ELEMENT_H_

typedef int Element;	

#endif

